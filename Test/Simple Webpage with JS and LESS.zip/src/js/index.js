﻿$(function () {
    $('.word')[0].innerHTML += "<br/>JS works well if this line appears.";
    // get your codes here
});